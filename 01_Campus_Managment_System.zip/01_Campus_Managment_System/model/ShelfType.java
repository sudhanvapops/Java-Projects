package model;

public enum ShelfType {
    MAIN,
    BORROWED;
}
