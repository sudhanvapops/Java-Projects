package model;

public enum Role {
    ADMIN,
    LIBRARIAN,
    BANKMANAGER,
    STUDENT,
}

